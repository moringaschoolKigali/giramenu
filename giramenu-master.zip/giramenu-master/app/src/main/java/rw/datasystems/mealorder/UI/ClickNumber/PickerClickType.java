package rw.datasystems.mealorder.UI.ClickNumber;

/**
 * I tells if picker value was increased or decreased
 */
public enum PickerClickType {

    NONE,
    LEFT,
    RIGHT;

}
