package rw.datasystems.mealorder.models;

import java.util.ArrayList;

import rw.datasystems.mealorder.Util.Constants;

/**
 * Created by vakinwande on 17/04/2017.
 */

public class LoadData {

    public LoadData() {

        Constants.categories = new ArrayList<>();

    }
}
